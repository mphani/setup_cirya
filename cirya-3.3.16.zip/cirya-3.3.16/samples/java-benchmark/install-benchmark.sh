mv ${archivePath} $HOME/aerospike-java-benchmark.jar

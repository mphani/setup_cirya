#!/bin/bash
mv ${archivePath} sherlock-cp-loader.tar
tar -xf sherlock-cp-loader.tar
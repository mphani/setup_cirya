# Amazon EC2 sample

Lauches aerospike directly over Amazon EC2.

TODO:
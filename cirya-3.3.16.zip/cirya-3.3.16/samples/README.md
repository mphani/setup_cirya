# Self contained samples

Assumes you have cirya-cli installed by following [this document](../README.md).

Self contained sample of using cirya-node to create and manage clusters for recreating various scenarios in standalone mode.

In order to try these example, on a terminal console, change directory to the desired sample folder (e.g. [mesh](mesh)), and refer to the corresponsing README.md file.

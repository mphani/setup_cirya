#!/bin/bash
mv ${archivePath} agni.tar
tar -xf agni.tar